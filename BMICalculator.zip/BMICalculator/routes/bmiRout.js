const express = require('express');
const router = express.Router();

// GET request для отображения HTML-шаблона
router.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, '../views/index.html'));
});

// POST request для обработки расчета ИМТ
router.post('/bmicalculator', (req, res) => {
    const height = parseFloat(req.body.height) / 100;
    const weight = parseFloat(req.body.weight);

    const bmi = weight / (height * height);

    let result = {
        bmi: bmi.toFixed(2),
        condition: ""
    };

    if (bmi < 18.5) {
        result.condition = "Underweight";
    } else if (bmi >= 18.5 && bmi <= 24.9) {
        result.condition = "Normal weight";
    } else if (bmi >= 25 && bmi <= 29.9) {
        result.condition = "Overweight";
    } else {
        result.condition = "Obesity";
    }

    res.json(result);
});

module.exports = router;
